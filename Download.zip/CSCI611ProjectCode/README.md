# CSCI611ProjectCode
  
admin.py and keygen.py are not completely finished/tested and have no direct impact on the client/server functionality.  
admin.py can be used to add, remove, and change passwords for users in the database.  
keygen.py generates new asymmetric key pairs.  


Note: Normally I wouldn't put keys and database files up here but for the purposes of the project it doesn't matter.
