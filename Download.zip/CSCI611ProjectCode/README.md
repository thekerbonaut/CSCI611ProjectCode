# CSCI611ProjectCode
admin.py and keygen.py can be ignored. They are unfinished and have no direct impact on the client/server functionality.
Normally I wouldn't put keys and database files up here but for the purposes of the project it doesn't matter.